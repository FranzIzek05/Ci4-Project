<?php

namespace App\Models;

use CodeIgniter\Model;

class CustomerModel extends Model
{
    protected $table = 'customer_accounts'; // ✅ corrected table name
    protected $primaryKey = 'account_number';
    protected $allowedFields = [
        'account_number', 
        'customer_name', 
        'address', 
        'email', 
        'phone', 
        'status', 
        'created_at', 
        'updated_at'
    ];
}
