<?php

namespace App\Models;
use CodeIgniter\Model;


class ServiceMode extends Model
{
    protected $table = 'menu_db';          // your table name
    protected $primaryKey = 'id';           // primary key
    protected $allowedFields = ['item_name', 'description', 'price', 'image'];
}






