<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PuihahaTea Café</title>
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      scroll-behavior: smooth;
    }

    body {
      font-family: 'Nunito', sans-serif;
      color: #333;
      background: #f9f5f0;
    }

    /* NAVIGATION */
    nav {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: rgba(50, 30, 20, 0.95);
      padding: 15px 50px;
      position: fixed;
      top: 0;
      width: 100%;
      z-index: 1000;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }

    .logo {
      font-family: 'Playfair Display', serif;
      font-size: 28px;
      color: #ffcc70;
      font-weight: 700;
      letter-spacing: 2px;
    }

    .nav-links {
      list-style: none;
      display: flex;
      gap: 25px;
    }

    .nav-link {
      text-decoration: none;
      color: #f4e1c6;
      font-weight: 700;
      font-size: 16px;
      position: relative;
      transition: color 0.3s;
    }

    .nav-link::after {
      content: "";
      position: absolute;
      width: 0;
      height: 2px;
      display: block;
      background: #ffcc70;
      transition: width .3s;
      bottom: -5px;
      left: 0;
    }

    .nav-link:hover {
      color: #ffcc70;
    }

    .nav-link:hover::after {
      width: 100%;
    }

    /* HERO SECTION */
    #home {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      padding: 0 20px;
      background: linear-gradient(rgba(0,0,0,0.45), rgba(0,0,0,0.45)), 
                  url("https://static.vecteezy.com/system/resources/thumbnails/051/899/260/small_2x/a-cozy-outdoor-cafe-with-empty-tables-and-chairs-lit-by-warm-hanging-lights-inside-a-barista-prepares-drinks-trees-and-parked-cars-are-visible-through-the-windows-video.jpg") center/cover no-repeat;
      color: #fff;
      position: relative;
      overflow: hidden;
    }

    #home h1 {
      font-size: 4rem;
      margin-bottom: 20px;
      letter-spacing: 2px;
      font-family: 'Playfair Display', serif;
      animation: fadeInUp 1.2s ease forwards;
    }

    #home p {
      max-width: 650px;
      line-height: 1.8;
      margin-bottom: 30px;
      font-size: 1.2rem;
      animation: fadeInUp 1.5s ease forwards;
    }

    .btn {
      padding: 14px 30px;
      background: #ffcc70;
      color: #3b2f2f;
      text-decoration: none;
      border-radius: 8px;
      transition: all 0.3s;
      font-weight: bold;
      box-shadow: 0 6px 15px rgba(0,0,0,0.2);
      animation: fadeInUp 1.8s ease forwards;
    }

    .btn:hover {
      background: #e6b35d;
      transform: translateY(-5px) scale(1.05);
      box-shadow: 0 10px 20px rgba(0,0,0,0.25);
    }

    /* FOOTER */
    footer {
      text-align: center;
      padding: 30px;
      background: #3b2f2f;
      color: #f4e1c6;
      font-size: 14px;
      letter-spacing: 1px;
      border-top: 3px solid #ffcc70;
    }

    .social-icons {
      margin-top: 10px;
    }

    .social-icons a {
      color: #f4e1c6;
      margin: 0 10px;
      font-size: 20px;
      transition: color 0.3s, transform 0.3s;
    }

    .social-icons a:hover {
      color: #ffcc70;
      transform: scale(1.2);
    }

    /* ANIMATIONS */
    @keyframes fadeInUp {
      0% {
        opacity: 0;
        transform: translateY(30px);
      }
      100% {
        opacity: 1;
        transform: translateY(0);
      }
    }

    /* RESPONSIVE */
    @media (max-width: 768px) {
      #home h1 { font-size: 2.8rem; }
      #home p { font-size: 1rem; }
      nav { padding: 15px 25px; }
      .nav-links { gap: 15px; }
    }

  </style>
</head>
<body>
  <?php helper('url'); ?>

  <nav>
    <div class="logo">PuihahaTea</div>
    <ul class="nav-links">
      <li><a href="register" class="nav-link">REGISTER</a></li>
      <li><a href="<?= base_url('puihahatea') ?>" class="nav-link">HOME</a></li>
      <li><a href="<?= base_url('about') ?>" class="nav-link">ABOUT US</a></li>
      <li><a href="<?= base_url('menu') ?>" class="nav-link">SERVICES</a></li>
      <li><a href="<?= base_url('contact') ?>" class="nav-link">CONTACT</a></li>
      <li><a href="dashboard" class="nav-link">DASHBOARD</a></li>
    </ul>
  </nav>

  <section id="home">
    <h1>Welcome to PuihahaTea</h1>
    <p>Where every cup is brewed with love and cozy vibes. Experience a warm and inviting ambiance perfect for your daily tea rituals or relaxing moments.</p>
    <a href="<?= base_url('menu') ?>" class="btn">Explore Our Menu</a>
  </section>

  <footer>
    <p>© 2025 PuihahaTea Café. All rights reserved.</p>
    <div class="social-icons">
      <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
      <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
    </div>
  </footer>
</body>
</html>
