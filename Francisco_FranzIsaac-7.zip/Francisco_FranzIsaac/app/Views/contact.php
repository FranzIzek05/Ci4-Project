<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PUIHAHATEA - Contact</title>
  <link
    href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700&family=Playfair+Display:wght@700&display=swap"
    rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      scroll-behavior: smooth;
    }

    body {
      font-family: 'Nunito', sans-serif;
      color: #333;
      background: #fefaf6;
    }

    nav {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: rgba(50, 30, 20, 0.95);
      padding: 15px 50px;
      position: fixed;
      top: 0;
      width: 100%;
      z-index: 1000;
    }

    .logo {
      font-family: 'Playfair Display', serif;
      font-size: 28px;
      color: #ffcc70;
      font-weight: 700;
    }

    .nav-links {
      list-style: none;
      display: flex;
      gap: 25px;
    }

    .nav-link {
      text-decoration: none;
      color: #f4e1c6;
      font-weight: 700;
      transition: color 0.3s, transform 0.3s;
    }

    .nav-link:hover {
      color: #ffcc70;
      transform: scale(1.1);
    }

    /* Contact Section */
    #contact {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      padding: 100px 20px 50px;
      background: linear-gradient(rgba(0, 0, 0, 0.45), rgba(0, 0, 0, 0.45)), url("https://c4.wallpaperflare.com/wallpaper/459/843/736/bar-bottle-juice-business-coffee-beans-wallpaper-preview.jpg") center/cover no-repeat;
      color: #fff;
      position: relative;
    }

    #contact h2 {
      font-size: 3rem;
      margin-bottom: 20px;
      font-family: 'Playfair Display', serif;
      font-weight: 700;
      letter-spacing: 1px;
    }

    #contact p {
      font-size: 1.1rem;
      margin-bottom: 10px;
    }

    /* Social Icons */
    .social-icons {
      display: flex;
      justify-content: center;
      gap: 20px;
      margin: 20px 0;
    }

    .social-icons img {
      width: 40px;
      height: 40px;
      transition: transform 0.3s, opacity 0.3s;
    }

    .social-icons img:hover {
      transform: scale(1.2);
      opacity: 0.8;
    }

    /* Contact form */
    .contact-form {
      background: rgba(255, 255, 255, 0.95);
      color: #333;
      padding: 40px;
      border-radius: 15px;
      max-width: 500px;
      width: 100%;
      margin-top: 30px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
    }

    .contact-form h3 {
      text-align: center;
      margin-bottom: 25px;
      font-family: 'Playfair Display', serif;
      color: #3b2f2f;
    }

    .contact-form input,
    .contact-form textarea {
      width: 100%;
      padding: 12px 15px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 1rem;
    }

    .contact-form button {
      width: 100%;
      padding: 15px;
      border: none;
      background: #ffcc70;
      color: #3b2f2f;
      font-size: 1.1rem;
      font-weight: 700;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s, transform 0.3s;
    }

    .contact-form button:hover {
      background: #e6b35d;
      transform: translateY(-3px);
    }

    footer {
      text-align: center;
      padding: 25px;
      background: #3b2f2f;
      color: #f4e1c6;
      font-size: 14px;
    }

    @media(max-width:768px) {
      nav {
        padding: 15px 20px;
      }

      #contact h2 {
        font-size: 2.5rem;
      }

      .contact-form {
        padding: 25px;
      }
    }

    .map-button {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 12px 20px;
      background-color: #ffcc70;
      color: #3b2f2f;
      font-weight: 700;
      text-decoration: none;
      border-radius: 8px;
      transition: background 0.3s, transform 0.3s;
      margin-top: 10px;
      font-size: 1.1rem;
    }

    .map-button i {
      font-size: 1.3rem;
    }

    .map-button:hover {
      background-color: #e6b35d;
      transform: translateY(-3px);
    }
  </style>
</head>

<body>
  <nav>
    <div class="logo">PuihahaTea</div>
    <ul class="nav-links">
      <li><a href="register" class="nav-link">REGISTER</a></li>
      <li><a href="puihahatea" class="nav-link">HOME</a></li>
      <li><a href="about" class="nav-link">ABOUT US</a></li>
      <li><a href="menu" class="nav-link">SERVICES</a></li>
      <li><a href="contact" class="nav-link">CONTACT</a></li>
      <li><a href="dashboard" class="nav-link">DASHBOARD</a></li>
    </ul>
  </nav>

  <section id="contact">
    <h2>Get in Touch</h2>
    <p>Email: hello@puihahatea.com</p>
    <p>Phone: 0900-000-0000</p>

    <!-- Stylish Visit Us section -->
    <p>Visit us at:</p>
    <a href="https://www.google.com/maps/place/123+Tea+Street,+Manila" target="_blank" class="map-button">
      <i class="fas fa-map-marker-alt"></i> 123 Tea Street, Manila
    </a>

    <!-- Social Icons -->
    <div class="social-icons">
      <a href="https://www.facebook.com" target="_blank"><img
          src="https://cdn-icons-png.flaticon.com/512/733/733547.png" alt="Facebook" /></a>
      <a href="https://www.instagram.com" target="_blank"><img
          src="https://cdn-icons-png.flaticon.com/512/174/174855.png" alt="Instagram" /></a>
    </div>

    <div class="contact-form">
      <h3>Send Us a Message</h3>
      <form action="send_message.php" method="POST">
        <input type="text" name="name" placeholder="Your Name" required>
        <input type="email" name="email" placeholder="Your Email" required>
        <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
        <button type="submit">Send Message</button>
      </form>
    </div>
  </section>


  <footer>
    <p>&copy; 2025 PUIHAHATEA. All Rights Reserved.</p>
  </footer>
</body>

</html>