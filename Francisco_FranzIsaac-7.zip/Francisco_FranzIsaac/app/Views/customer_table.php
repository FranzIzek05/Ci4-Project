<table>
  <thead>
    <tr>
      <th>Account #</th>
      <th>Name</th>
      <th>Address</th>
      <th>Email</th>
      <th>CP #</th>
      <th>Status</th>
      <th>Created At</th>
      <th>Updated At</th>
    </tr>
  </thead>
  <tbody>
    <?php if (!empty($customers)): ?>
      <?php foreach ($customers as $row): ?>
        <tr>
          <td><?= esc($row['account_number']) ?></td>
          <td><?= esc($row['customer_name']) ?></td>
          <td><?= esc($row['address']) ?></td>
          <td><?= esc($row['email']) ?></td>
          <td><?= esc($row['phone']) ?></td>
          <td><?= esc($row['status']) ?></td>
          <td><?= esc($row['created_at']) ?></td>
          <td><?= esc($row['updated_at']) ?></td>
        </tr>
      <?php endforeach; ?>
    <?php else: ?>
      <tr>
        <td colspan="8" style="text-align:center;">No customers found.</td>
      </tr>
    <?php endif; ?>
  </tbody>
</table>

<div class="pagination-wrapper">
  <?= $pager->links('group1', 'numeric') ?>
</div>
