<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PuihahaTea Dashboard</title>
  <link
    href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700&family=Playfair+Display:wght@700&display=swap"
    rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      scroll-behavior: smooth;
    }

    body {
      font-family: 'Nunito', sans-serif;
      color: #333;
      background: #f9f5f0;
      padding-top: 100px;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    nav {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: rgba(50, 30, 20, 0.95);
      padding: 15px 50px;
      position: fixed;
      top: 0;
      width: 100%;
      z-index: 1000;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .logo {
      font-family: 'Playfair Display', serif;
      font-size: 28px;
      color: #ffcc70;
      font-weight: 700;
      letter-spacing: 2px;
    }

    .nav-links {
      list-style: none;
      display: flex;
      gap: 25px;
    }

    .nav-link {
      text-decoration: none;
      color: #f4e1c6;
      font-weight: 700;
      font-size: 16px;
      position: relative;
      transition: color 0.3s;
    }

    .nav-link:hover {
      color: #ffcc70;
    }

    .dashboard-container {
      flex: 1;
      width: 90%;
      margin: 0 auto 60px auto;
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      padding: 30px 30px 80px 30px;
      position: relative;
      z-index: 10;
    }

    .dashboard-container h1 {
      font-family: 'Playfair Display', serif;
      color: #3b2f2f;
      text-align: center;
      margin-bottom: 20px;
    }

    .search-bar {
      display: flex;
      justify-content: center;
      gap: 10px;
      margin-bottom: 25px;
      flex-wrap: wrap;
    }

    input[type="text"],
    select {
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    button {
      padding: 10px 15px;
      background: #ffcc70;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-weight: bold;
    }

    .btn-add {
      background-color: #3b2f2f;
      color: #fff;
      margin-bottom: 15px;
      float: right;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th,
    td {
      padding: 12px;
      border-bottom: 1px solid #ddd;
      text-align: left;
    }

    th {
      background: #ffcc70;
      color: #3b2f2f;
    }

    tr:hover {
      background: #f9f2e4;
    }

    .actions button {
      padding: 6px 10px;
      border: none;
      border-radius: 5px;
      color: #fff;
      font-size: 14px;
      cursor: pointer;
    }

    .edit-btn {
      background-color: #ffc107;
    }

    .delete-btn {
      background-color: #dc3545;
    }

    .pagination-wrapper {
      display: flex;
      justify-content: center;
      margin-top: 40px;
    }

    footer {
      text-align: center;
      padding: 30px;
      background: #3b2f2f;
      color: #f4e1c6;
      font-size: 14px;
      border-top: 3px solid #ffcc70;
      margin-top: auto;
    }

    .social-icons a {
      color: #f4e1c6;
      margin: 0 10px;
      font-size: 20px;
      transition: 0.3s;
    }

    .social-icons a:hover {
      color: #ffcc70;
    }

    /* MODAL STYLES */
    .modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.6);
      justify-content: center;
      align-items: center;
      z-index: 2000;
    }

    .modal-content {
      background: white;
      padding: 25px;
      border-radius: 10px;
      width: 400px;
    }

    .modal-content h2 {
      margin-bottom: 15px;
      text-align: center;
      color: #3b2f2f;
    }

    .modal-content input {
      width: 100%;
      padding: 10px;
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    .modal-content button {
      width: 48%;
      margin-top: 10px;
    }
  </style>
</head>

<body>
  <?php helper('url'); ?>

  <nav>
    <div class="logo">PuihahaTea</div>
    <ul class="nav-links">
      <li><a href="register" class="nav-link">REGISTER</a></li>
      <li><a href="<?= base_url('puihahatea') ?>" class="nav-link">HOME</a></li>
      <li><a href="<?= base_url('about') ?>" class="nav-link">ABOUT US</a></li>
      <li><a href="<?= base_url('menu') ?>" class="nav-link">SERVICES</a></li>
      <li><a href="<?= base_url('contact') ?>" class="nav-link">CONTACT</a></li>
      <li><a href="<?= base_url('dashboard') ?>" class="nav-link" style="color:#ffcc70;">DASHBOARD</a></li>
    </ul>
  </nav>

  <section class="dashboard-container">
    <h1>Customer Dashboard</h1>

    <button class="btn-add" onclick="openModal('addModal')">+ Add Customer</button>

    <form method="get" class="search-bar">
      <input type="text" name="search" placeholder="Search by Name, CP, or Status" value="<?= esc($search) ?>">
      <select name="per_page" onchange="this.form.submit()">
        <option value="10" <?= $perPage == 10 ? 'selected' : '' ?>>10</option>
        <option value="20" <?= $perPage == 20 ? 'selected' : '' ?>>20</option>
        <option value="50" <?= $perPage == 50 ? 'selected' : '' ?>>50</option>
        <option value="100" <?= $perPage == 100 ? 'selected' : '' ?>>100</option>
      </select>
      <button type="submit">Search</button>
    </form>

    <table>
      <thead>
        <tr>
          <th>Account #</th>
          <th>Name</th>
          <th>Address</th>
          <th>Email</th>
          <th>CP #</th>
          <th>Status</th>
          <th>Created At</th>
          <th>Updated At</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($customers)): ?>
          <?php foreach ($customers as $row): ?>
            <tr>
              <td><?= esc($row['account_number']) ?></td>
              <td><?= esc($row['customer_name']) ?></td>
              <td><?= esc($row['address']) ?></td>
              <td><?= esc($row['email']) ?></td>
              <td><?= esc($row['phone']) ?></td>
              <td><?= esc($row['status']) ?></td>
              <td><?= esc($row['created_at']) ?></td>
              <td><?= esc($row['updated_at']) ?></td>
              <td class="actions">
                <button class="edit-btn" onclick="openEditModal(
                  '<?= $row['account_number'] ?>',
                  '<?= esc($row['customer_name']) ?>',
                  '<?= esc($row['address']) ?>',
                  '<?= esc($row['email']) ?>',
                  '<?= esc($row['phone']) ?>',
                  '<?= esc($row['status']) ?>'
                )">Edit</button>
                <form method="post" action="<?= base_url('customer/delete/' . $row['account_number']) ?>"
                  style="display:inline;">
                  <?= csrf_field() ?>
                  <button type="submit" class="delete-btn" onclick="return confirm('Are you sure?')">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="9" style="text-align:center;">No customers found.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>

    <div class="pagination-wrapper">
      <?= $pager->links('group1', 'numeric') ?>
    </div>
  </section>

  <!-- Add Modal -->
  <div id="addModal" class="modal">
    <div class="modal-content">
      <h2>Add Customer</h2>
      <form action="<?= base_url('customer/create') ?>" method="post">
        <input type="text" name="customer_name" placeholder="Customer Name" required>
        <input type="text" name="address" placeholder="Address" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="phone" placeholder="Phone" required>
        <input type="text" name="status" placeholder="Status" required>
        <button type="submit">Save</button>
        <button type="button" onclick="closeModal('addModal')">Cancel</button>
      </form>
    </div>
  </div>

  <!-- Edit Modal -->
  <div id="editModal" class="modal">
    <div class="modal-content">
      <h2>Edit Customer</h2>
      <form id="editForm" method="post">
        <input type="hidden" name="account_number" id="edit_account_number">
        <input type="text" name="customer_name" id="edit_customer_name" required>
        <input type="text" name="address" id="edit_address" required>
        <input type="email" name="email" id="edit_email" required>
        <input type="text" name="phone" id="edit_phone" required>
        <input type="text" name="status" id="edit_status" required>
        <button type="submit">Update</button>
        <button type="button" onclick="closeModal('editModal')">Cancel</button>
      </form>
    </div>
  </div>

  <footer>
    <p>© 2025 PuihahaTea Café. All rights reserved.</p>
    <div class="social-icons">
      <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
      <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
    </div>
  </footer>

  <script>
    function openModal(id) {
      document.getElementById(id).style.display = 'flex';
    }
    function closeModal(id) {
      document.getElementById(id).style.display = 'none';
    }

    // ✅ When opening edit modal, set proper action route
    function openEditModal(acc, name, address, email, phone, status) {
      document.getElementById('edit_account_number').value = acc;
      document.getElementById('edit_customer_name').value = name;
      document.getElementById('edit_address').value = address;
      document.getElementById('edit_email').value = email;
      document.getElementById('edit_phone').value = phone;
      document.getElementById('edit_status').value = status;

      // ✅ Update the edit form action dynamically
      document.getElementById('editForm').action = "<?= base_url('customer/update/') ?>" + acc;

      openModal('editModal');
    }
  </script>
</body>

</html>