<?php 
$pager->setSurroundCount(2);
$links = $pager->links(); 
?>
<!-- ✅ Add wrapper with margin so it appears below table and navbar -->
<div class="pagination-wrapper" style="margin: 40px auto 0 auto; text-align:center;">
    <ul class="pagination">
        <?php if ($pager->hasPrevious()) : ?>
            <li><a href="<?= $pager->getFirst() ?>">First</a></li>
            <li><a href="<?= $pager->getPrevious() ?>">&laquo;</a></li>
        <?php endif ?>

        <?php foreach ($links as $link) : ?>
            <li class="<?= $link['active'] ? 'active' : '' ?>">
                <a href="<?= $link['uri'] ?>"><?= $link['title'] ?></a>
            </li>
        <?php endforeach ?>

        <?php if ($pager->hasNext()) : ?>
            <li><a href="<?= $pager->getNext() ?>">&raquo;</a></li>
            <li><a href="<?= $pager->getLast() ?>">Last</a></li>
        <?php endif ?>
    </ul>
</div>

<style>
.pagination-wrapper ul {
    display: flex;
    justify-content: center;
    list-style: none;
    padding: 0;
    gap: 10px;
}

.pagination-wrapper li a,
.pagination-wrapper li span {
    padding: 10px 15px;
    border: 1px solid #c0a36e;
    border-radius: 8px;
    color: #5a3e1b;
    text-decoration: none;
    font-weight: 500;
    transition: all 0.3s ease;
}

.pagination-wrapper li.active span,
.pagination-wrapper li a:hover {
    background-color: #c0a36e;
    color: white;
}
</style>
