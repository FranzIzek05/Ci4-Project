<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PuihahaTea - Register</title>
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">


  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      scroll-behavior: smooth;
    }


    body {
      font-family: 'Nunito', sans-serif;
      background: #f9f5f0;
      color: #333;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }


    nav {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: rgba(50, 30, 20, 0.95);
      padding: 15px 50px;
      position: fixed;
      top: 0;
      width: 100%;
      z-index: 1000;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }


    .logo {
      font-family: 'Playfair Display', serif;
      font-size: 28px;
      color: #ffcc70;
      font-weight: 700;
      letter-spacing: 2px;
    }


    .nav-links {
      list-style: none;
      display: flex;
      gap: 25px;
    }


    .nav-link {
      text-decoration: none;
      color: #f4e1c6;
      font-weight: 700;
      font-size: 16px;
      transition: color 0.3s;
    }


    .nav-link:hover {
      color: #ffcc70;
    }


    .register-container {
      flex: 1;
      width: 90%;
      max-width: 500px;
      margin: 140px auto;
      background: #fff;
      border-radius: 10px;
      padding: 30px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }


    h1 {
      font-family: 'Playfair Display', serif;
      color: #3b2f2f;
      text-align: center;
      margin-bottom: 25px;
    }


    form input {
      width: 100%;
      padding: 12px;
      margin-bottom: 15px;
      border-radius: 5px;
      border: 1px solid #ccc;
      font-size: 15px;
    }


    form button {
      width: 100%;
      padding: 12px;
      background: #3b2f2f;
      color: #fff;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      transition: background 0.3s;
    }


    form button:hover {
      background: #ffcc70;
      color: #3b2f2f;
    }


    .alert {
      padding: 10px;
      background: #ffdddd;
      color: #a33;
      margin-bottom: 10px;
      border: 1px solid #e99;
      border-radius: 5px;
    }


    footer {
      text-align: center;
      padding: 30px;
      background: #3b2f2f;
      color: #f4e1c6;
      font-size: 14px;
      border-top: 3px solid #ffcc70;
      margin-top: auto;
    }


    .social-icons a {
      color: #f4e1c6;
      margin: 0 10px;
      font-size: 20px;
      transition: 0.3s;
    }


    .social-icons a:hover {
      color: #ffcc70;
    }
  </style>
</head>


<body>
  <?php helper('url'); ?>


  <nav>
    <div class="logo">PuihahaTea</div>
    <ul class="nav-links">
      <li><a href="<?= base_url('register') ?>" class="nav-link">REGISTER</a></li>
      <li><a href="<?= base_url('puihahatea') ?>" class="nav-link">HOME</a></li>
      <li><a href="<?= base_url('about') ?>" class="nav-link">ABOUT US</a></li>
      <li><a href="<?= base_url('menu') ?>" class="nav-link">SERVICES</a></li>
      <li><a href="<?= base_url('contact') ?>" class="nav-link">CONTACT</a></li>
      <li><a href="<?= base_url('dashboard') ?>" class="nav-link">DASHBOARD</a></li>
    </ul>
  </nav>


  <section class="register-container">
    <h1>Customer Registration</h1>


    <?php if (session()->getFlashdata('error')): ?>
      <div class="alert"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>


    <?php if (session()->getFlashdata('message')): ?>
      <div class="alert" style="background:#ddffdd; color:#060; border:1px solid #9c9;">
        <?= session()->getFlashdata('message') ?>
      </div>
    <?php endif; ?>


    <form action="<?= base_url('register/submit') ?>" method="post">
      <?= csrf_field() ?>
      <input type="text" id="name" name="name" placeholder="Full Name" required>
      <input type="email" id="email" name="email" placeholder="Email" required>
      <input type="password" id="password" name="password" placeholder="Password" required minlength="6">
      <button type="submit">Register</button>
    </form>
  </section>


  <footer>
    <p>© 2025 PuihahaTea Café. All rights reserved.</p>
    <div class="social-icons">
      <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
      <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
    </div>
  </footer>
</body>
</html>


