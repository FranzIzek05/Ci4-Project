<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PUIHAHATEA - Menu</title>
  <link
    href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700&family=Playfair+Display:wght@700&display=swap"
    rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      scroll-behavior: smooth;
    }

    body {
      font-family: 'Nunito Sans', sans-serif;
      color: #333;
      background-image: url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0_h_Hgl1M3-AbHTZOsGL3ka0Y3vampnroMg&s');
      background-size: cover;
      background-repeat: no-repeat;
      background-attachment: fixed;
    }

    nav {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: rgba(50, 30, 20, 0.95);
      padding: 15px 50px;
      position: fixed;
      top: 0;
      width: 100%;
      z-index: 1000;
    }

    .logo {
      font-size: 24px;
      font-weight: bold;
      color: #f4e1c6;
      font-family: 'Franz FW Merriweather', serif;
    }

    .nav-links {
      list-style: none;
      display: flex;
      gap: 20px;
    }

    .nav-link {
      text-decoration: none;
      color: #f4e1c6;
      font-weight: bold;
      transition: color 0.3s, transform 0.3s;
    }

    .nav-link:hover {
      color: #ffcc70;
      transform: scale(1.1);
    }

    section {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      align-items: center;
      text-align: center;
      padding: 120px 50px 50px;
      color: white;
      position: relative;
    }

    section::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.55);
      z-index: 0;
    }

    section>* {
      position: relative;
      z-index: 1;
    }

    h1,
    h2 {
      font-size: 3rem;
      margin-bottom: 20px;
    }

    p {
      max-width: 600px;
      line-height: 1.6;
      margin-bottom: 20px;
    }

    .menu-container {
      width: 90%;
      max-width: 1000px;
      margin: 30px auto 0;
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .menu-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 30px;
      width: 100%;
      margin-top: 30px;
    }

    .menu-item {
      background: rgba(255, 255, 255, 0.95);
      color: #3b2f2f;
      padding: 20px;
      border-radius: 10px;
      transition: transform 0.3s;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    }

    .menu-item:hover {
      transform: scale(1.05);
    }

    .menu-item img {
      width: 100%;
      height: 150px;
      object-fit: cover;
      border-radius: 8px;
      margin-bottom: 15px;
    }

    .menu-item h3 {
      margin-bottom: 50px;
      color: #a0522d;
    }

    .pagination-nav {
      position: relative !important;
      top: auto !important;
      z-index: 1 !important;
      background: transparent !important;
      margin-top: 40px;
    }

    .pagination-wrapper {
      display: flex;
      justify-content: center;
      /* centers horizontally */
      align-items: center;
      /* centers vertically if there's height */
      margin: 30px auto;
      width: 100%;
      text-align: center;
    }

    .pagination-nav {
      display: inline-block;
      position: relative !important;
      background: transparent !important;
    }

    .pagination-nav ul {
      display: flex;
      gap: 10px;
      list-style: none;
      justify-content: center;
      padding: 0;
    }

    .pagination-nav li a,
    .pagination-nav li span {
      padding: 10px 15px;
      border: 1px solid #c0a36e;
      border-radius: 8px;
      color: #5a3e1b;
      text-decoration: none;
      font-weight: 500;
      transition: all 0.3s ease;
    }

    .pagination-nav li.active span,
    .pagination-nav li a:hover {
      background-color: #c0a36e;
      color: white;
    }





    footer {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      padding: 30px;
      background: #3b2f2f;
      color: #f4e1c6;
      font-size: 14px;
      letter-spacing: 1px;
      border-top: 3px solid #ffcc70;
    }

    .social-icons {
      margin-top: 10px;
      display: flex;
      gap: 15px;
    }

    .social-icons a {
      color: #f4e1c6;
      font-size: 20px;
      transition: color 0.3s, transform 0.3s;
    }

    .social-icons a:hover {
      color: #ffcc70;
      transform: scale(1.2);
    }
  </style>
</head>

<body>
  <nav>
    <div class="logo">PuihahaTea</div>
    <ul class="nav-links">
      <li><a href="register" class="nav-link">REGISTER</a></li>
      <li><a href="puihahatea" class="nav-link">HOME</a></li>
      <li><a href="about" class="nav-link">ABOUT US</a></li>
      <li><a href="menu" class="nav-link">SERVICES</a></li>
      <li><a href="contact" class="nav-link">CONTACT</a></li>
      <li><a href="dashboard" class="nav-link">DASHBOARD</a></li>
    </ul>
  </nav>

  <section id="menu">
    <h2>Services</h2>

    <div class="menu-container">
      <div class="menu-grid">
        <?php if (!empty($services)): ?>
          <?php foreach ($services as $service): ?>
            <div class="menu-item">
              <img src="<?= esc($service['image']); ?>" alt="<?= esc($service['item_name']); ?>">
              <h3><?= esc($service['item_name']); ?></h3>
              <p><?= esc($service['description']); ?> ₱<?= esc($service['price']); ?></p>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <p>No menu items available at the moment.</p>
        <?php endif; ?>
      </div>

      <div class="pagination-wrapper">
        <?= $pager->links('group1', 'numeric'); ?>
      </div>
    </div>
  </section>


  <footer>
    <p>© 2025 PUIHAHATEA All Rights Reserved</p>
    <div class="social-icons">
      <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
      <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
    </div>
  </footer>

</body>

</html>