<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Customer</title>
</head>
<body style="font-family:sans-serif;background:#f8f8f8;padding:40px;">
  <h1>Edit Customer</h1>

  <form action="<?= base_url('customer/update/' . $customer['id']) ?>" method="post" style="max-width:600px;margin-top:20px;">
    <input type="text" name="account_number" value="<?= esc($customer['account_number']) ?>" required style="width:100%;margin:5px 0;padding:10px;">
    <input type="text" name="customer_name" value="<?= esc($customer['customer_name']) ?>" required style="width:100%;margin:5px 0;padding:10px;">
    <input type="text" name="address" value="<?= esc($customer['address']) ?>" required style="width:100%;margin:5px 0;padding:10px;">
    <input type="email" name="email" value="<?= esc($customer['email']) ?>" required style="width:100%;margin:5px 0;padding:10px;">
    <input type="text" name="phone" value="<?= esc($customer['phone']) ?>" required style="width:100%;margin:5px 0;padding:10px;">
    <input type="text" name="status" value="<?= esc($customer['status']) ?>" required style="width:100%;margin:5px 0;padding:10px;">
    <button type="submit">Save Changes</button>
  </form>

  <p><a href="<?= base_url('dashboard') ?>">← Back to Dashboard</a></p>
</body>
</html>
