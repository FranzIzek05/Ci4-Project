<?php

namespace App\Controllers;
use App\Models\ServiceMode;

class Pages extends BaseController
{
    public function puihahatea()
    {
        return view('puihahatea');
    }

    public function about()
    {
        return view('about');
    }

    public function menu()
    {
        $model = new ServiceMode();
        $perPage = 6; // number of items per page

        // Fetch paginated data
        $data['services'] = $model->paginate($perPage, 'group1');
        $data['pager'] = $model->pager;

        // ✅ If the request is made via AJAX (pagination click)
        if ($this->request->isAJAX()) {
            echo view('menu', $data);
            return;
        }

        // ✅ Normal first page load
        return view('menu', $data);
    }
    public function dashboard()
    {
        $model = new ServiceMode();
        $perPage = 6; // number of items per page

        // Fetch paginated data
        $data['dashboard'] = $model->paginate($perPage, 'group1');
        $data['pager'] = $model->pager;

        // ✅ If the request is made via AJAX (pagination click)
        if ($this->request->isAJAX()) {
            echo view('menu', $data);
            return;
        }

        // ✅ Normal first page load
        return view('menu', $data);
    }

    public function contact()
    {
        return view('contact');
    }
}
