<?php


namespace App\Controllers;


use App\Models\UserModel;
use CodeIgniter\Controller;
use Config\Services;


class RegisterController extends Controller
{
    public function registerForm()
    {
        return view('register');
    }


    public function registerUser()
    {
        $model = new UserModel();
        $validation = Services::validation();


        $validation->setRules([
            'name'     => 'required|min_length[3]',
            'email'    => 'required|valid_email|is_unique[users.email]',
            'password' => 'required|min_length[6]'
        ]);


        if (!$validation->withRequest($this->request)->run()) {
            return view('register', ['validation' => $validation]);
        }


        $token = bin2hex(random_bytes(16));


        $data = [
            'name'               => $this->request->getPost('name'),
            'email'              => $this->request->getPost('email'),
            'password'           => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'verification_token' => $token,
            'is_verified'        => 0,
            'created_at'         => date('Y-m-d H:i:s')
        ];


        $model->insert($data);


        // ✅ Send verification email
        $this->sendVerificationEmail($data['email'], $token);


        return redirect()->to('/register')->with('message', 'Verification email sent! Check your inbox.');
    }


    private function sendVerificationEmail($email, $token)
    {
        $subject = "Verify your PUIHAHA TEA account";
        $message = "
            <p>Thank you for registering at <b>PUIHAHA TEA</b>!</p>
            <p>Please click the link below to verify your email:</p>
            <p><a href='" . base_url('verify/' . $token) . "'>Verify Account</a></p>
        ";


        $emailService = Services::email();
        $emailService->setTo($email);
        $emailService->setFrom('franzisaacfrancisco@gmail.com', 'PUIHAHA TEA');
        $emailService->setSubject($subject);
        $emailService->setMessage($message);


        if (!$emailService->send()) {
            log_message('error', 'Email sending failed: ' . $emailService->printDebugger(['headers']));
        }
    }


    public function verify($token)
    {
        $model = new UserModel();
        $user = $model->where('verification_token', $token)->first();


        if ($user) {
            $model->update($user['id'], [
                'is_verified' => 1,
                'verification_token' => null
            ]);


            return redirect()->to('/dashboard')->with('message', 'Email verified successfully!');
        }


        return redirect()->to('/register')->with('error', 'Invalid or expired verification link!');
    }
}
