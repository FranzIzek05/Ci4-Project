<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function puihahatea()
    {
        return view('puihahatea');
    }

    public function about ()
    {
        return view('about');
    }

    public function menu ()
    {
        return view('menu');
    }

    public function contact ()
    {
        return view('contact');
    }
}

