<?php


namespace App\Controllers;


use App\Models\CustomerModel;
use CodeIgniter\Controller;
use Config\Services;


class CustomerController extends Controller
{
    // ✅ DASHBOARD - List customers
    public function index()
    {
        $model = new CustomerModel();


        $search = $this->request->getGet('search');
        $perPage = $this->request->getGet('per_page') ?? 10;


        if ($search) {
            $model->groupStart()
                  ->like('customer_name', $search)
                  ->orLike('phone', $search)
                  ->orLike('status', $search)
                  ->groupEnd();
        }


        $customers = $model->paginate($perPage, 'group1');


        $data = [
            'customers' => $customers,
            'pager'     => $model->pager,
            'search'    => $search,
            'perPage'   => $perPage,
        ];


        return view('dashboard', $data);
    }


    // ✅ CREATE (Add new customer manually in dashboard)
    public function create()
    {
        $model = new CustomerModel();


        // Auto-generate account_number
        $usedNumbers = $model->select('account_number')->findAll();
        $numbers = [];


        foreach ($usedNumbers as $c) {
            $numbers[] = (int) substr($c['account_number'], 3);
        }


        $newNumber = 1;
        while (in_array($newNumber, $numbers)) {
            $newNumber++;
        }


        $account_number = 'ACC' . str_pad($newNumber, 4, '0', STR_PAD_LEFT);


        $data = [
            'account_number' => $account_number,
            'customer_name'  => $this->request->getPost('customer_name'),
            'address'        => $this->request->getPost('address'),
            'email'          => $this->request->getPost('email'),
            'phone'          => $this->request->getPost('phone'),
            'status'         => $this->request->getPost('status'),
        ];


        $model->insert($data);


        return redirect()->to('/dashboard')->with('message', 'Customer added successfully!');
    }


    // ✅ EDIT (Load customer data for edit modal)
    public function edit($account_number)
    {
        $model = new CustomerModel();
        $customer = $model->where('account_number', $account_number)->first();


        if (!$customer) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Customer with ID $account_number not found");
        }


        return view('edit_customer', ['customer' => $customer]);
    }


    // ✅ UPDATE (Save edited customer)
    public function update($account_number)
    {
        $model = new CustomerModel();


        $customer = $model->where('account_number', $account_number)->first();
        if (!$customer) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Customer with ID $account_number not found");
        }


        $data = [
            'customer_name' => $this->request->getPost('customer_name'),
            'address'       => $this->request->getPost('address'),
            'email'         => $this->request->getPost('email'),
            'phone'         => $this->request->getPost('phone'),
            'status'        => $this->request->getPost('status'),
        ];


        $model->where('account_number', $account_number)->set($data)->update();


        return redirect()->to('/dashboard')->with('message', 'Customer updated successfully!');
    }


    // ✅ DELETE (Remove customer)
    public function delete($account_number)
    {
        $model = new CustomerModel();


        $customer = $model->where('account_number', $account_number)->first();
        if (!$customer) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Customer with ID $account_number not found");
        }


        $model->where('account_number', $account_number)->delete();


        return redirect()->to('/dashboard')->with('message', 'Customer deleted successfully!');
    }


    // 🧍‍♂️ REGISTER - Show registration form
    public function register()
    {
        return view('register');
    }


    // 📨 SUBMIT REGISTRATION - Validate, save, and send verification email
    public function submitRegistration()
    {
        $validation = Services::validation();


        $rules = [
            'customer_name' => 'required|min_length[3]',
            'email'         => 'required|valid_email|is_unique[customers.email]',
            'address'       => 'required',
            'phone'         => 'required|min_length[10]',
            'password'      => 'required|min_length[6]'
        ];


        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', implode('<br>', $validation->getErrors()));
        }


        $model = new CustomerModel();


        $verificationToken = bin2hex(random_bytes(16));


        $data = [
            'customer_name' => $this->request->getPost('customer_name'),
            'email'         => $this->request->getPost('email'),
            'address'       => $this->request->getPost('address'),
            'phone'         => $this->request->getPost('phone'),
            'password'      => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'status'        => 'Pending Verification',
            'verify_token'  => $verificationToken,
            'created_at'    => date('Y-m-d H:i:s')
        ];


        $model->insert($data);


        // ✉️ Send email verification
        $email = Services::email();
        $email->setTo($this->request->getPost('email'));
        $email->setFrom('franzisaacfrancisco@gmail.com', 'PUIHAHA TEA Registration');
        $email->setSubject('Verify Your Email - PUIHAHA TEA');
        $email->setMessage("
            Hi " . esc($this->request->getPost('customer_name')) . ",<br><br>
            Thank you for registering at <b>PUIHAHA TEA</b>!<br>
            Please verify your email by clicking the link below:<br><br>
            <a href='" . base_url('verify-email/' . $verificationToken) . "'>Verify Email</a><br><br>
            After verification, you’ll be redirected to your Dashboard.
        ");
        $email->send();


        return redirect()->to(base_url('register'))
            ->with('message', 'Registration successful! Please check your email for verification.');
    }


    // ✅ VERIFY EMAIL LINK
    public function verifyEmail($token)
    {
        $model = new CustomerModel();
        $customer = $model->where('verify_token', $token)->first();


        if ($customer) {
            $model->update($customer['id'], [
                'status'       => 'Verified',
                'verify_token' => null
            ]);


            return redirect()->to(base_url('dashboard'))
                ->with('message', 'Email verified successfully! Welcome to your dashboard.');
        }


        return redirect()->to(base_url('register'))
            ->with('error', 'Invalid or expired verification token.');
    }
}
