<?php


use CodeIgniter\Router\RouteCollection;


/**
 * @var RouteCollection $routes
 */


// ---------------------------
// 🌿 Main Pages
// ---------------------------
$routes->get('/', 'Home::puihahatea');
$routes->get('puihahatea', 'Home::puihahatea');
$routes->get('about', 'Home::about');
$routes->get('menu', 'Pages::menu');
$routes->get('contact', 'Home::contact');


// ---------------------------
// 📊 Dashboard (Customer Management)
// ---------------------------
$routes->get('dashboard', 'CustomerController::index');


// ---------------------------
// 🧾 Customer CRUD Operations
// ---------------------------


// ✅ Create (Add new customer)
$routes->post('customer/create', 'CustomerController::create');


// ✅ Edit (Load edit data)
$routes->get('customer/edit/(:any)', 'CustomerController::edit/$1');


// ✅ Update (Save edited data)
$routes->post('customer/update/(:any)', 'CustomerController::update/$1');


// ✅ Delete (Remove record)
$routes->post('customer/delete/(:any)', 'CustomerController::delete/$1');

// ---------------------------
// 🧍 Registration Routes
// ---------------------------
$routes->get('register', 'RegisterController::registerForm');
$routes->post('register/submit', 'RegisterController::registerUser'); // ✅ fixed line
$routes->get('verify/(:any)', 'RegisterController::verify/$1');













